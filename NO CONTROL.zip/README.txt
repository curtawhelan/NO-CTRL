Curt Whelan
NO CTRL

In Unity the players move and shoot toward the player but after building they will not
move or aim at player



Controls: WASD for movement, aim with mouse


https://opengameart.org/content/top-down-dungeon-tileset
https://assetstore.unity.com/packages/2d/free-2d-mega-pack-177430
https://www.dafont.com/perfect-dos-vga-437.font
https://assetstore.unity.com/packages/audio/music/electronic/the-8-bit-jukebox-lite-music-pack-70436
For scripting tutorials I used Brackeys videos